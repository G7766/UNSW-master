## import modules here 
import pandas as pd
import numpy as np



################# Question 1 #################

def v_opt_dp(x, num_bins):# do not change the heading of the function
    pass # **replace** this line with your code
