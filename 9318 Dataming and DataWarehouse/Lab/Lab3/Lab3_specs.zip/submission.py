def logistic_regression(data, labels, weights, num_epochs, learning_rate): # do not change the heading of the function
    pass # **replace** this line with your code
