package assignment1;

/**
 * 
 * This class solves the problem posed for Assignment1
 *
 */
public class Assignment1 {
  
// TODO: Write the source code for your solution here.	
	
}